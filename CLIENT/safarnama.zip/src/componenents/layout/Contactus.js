import React from 'react';

const Contact = () => {
  return (
    <div >
      <h1>Welcome To Safarnama </h1>
      <hr/>
      <section className='container,mt-5 mb-5'>
      <fieldset>
        <legend>Contact Us</legend>
        <a href='mailto:safarnam@contactus.gmail.com'> Mail us to register your hotel</a>
      </fieldset>
      </section>
</div>
                                       
  );
};

export default Contact;
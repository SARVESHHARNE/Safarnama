import React from 'react';
import { BiSolidMessageSquareDots } from "react-icons/bi";
import { Link } from 'react-router-dom';

const Floating = () => {
  return (
    <div className="floating-icon">
       
      <a href='/contact-us'><BiSolidMessageSquareDots className='floating-io'/></a>
    </div> 
  );
};

export default Floating;
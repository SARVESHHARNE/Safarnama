package com.backend.safarnama.controller;

public class BookedRoomController {

}

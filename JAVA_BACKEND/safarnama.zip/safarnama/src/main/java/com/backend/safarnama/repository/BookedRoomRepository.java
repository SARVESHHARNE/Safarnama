package com.backend.safarnama.repository;

public interface BookedRoomRepository {

}

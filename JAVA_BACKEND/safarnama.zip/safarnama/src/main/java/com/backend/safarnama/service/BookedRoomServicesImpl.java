package com.backend.safarnama.service;

public class BookedRoomServicesImpl implements IBookedRoomServices {

}

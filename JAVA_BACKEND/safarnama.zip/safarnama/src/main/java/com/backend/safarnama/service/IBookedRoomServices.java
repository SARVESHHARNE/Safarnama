package com.backend.safarnama.service;

public interface IBookedRoomServices {

}

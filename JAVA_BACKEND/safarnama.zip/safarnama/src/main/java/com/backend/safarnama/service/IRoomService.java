package com.backend.safarnama.service;

import java.io.IOException;
import java.sql.SQLException;

import javax.sql.rowset.serial.SerialException;

import org.springframework.web.multipart.MultipartFile;

import com.backend.safarnama.model.Room;

public interface IRoomService {

	Room addNewRoom(MultipartFile photo, String roomNO, String roomType, double roomPrice, int capacity) throws IOException, SerialException, SQLException;

}
